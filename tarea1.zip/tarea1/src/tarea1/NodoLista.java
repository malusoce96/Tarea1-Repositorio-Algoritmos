/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tarea1;

/**
 *
 * @author lucia
 */
public class NodoLista {
    
    /**
    datos a guardar en el nodo
    */
    private Object datos;
    /**
     * siguiente nodo
     */
    
    //ignore lo dicho:) ;) prosigamos xfa :D
    NodoLista siguienteNodo;
    
    /**
     * contructor de la clase que hace referencia al objeto
     * @param datos: datos a insertar 
     */
    NodoLista (Object datos){
        this(datos, null);
        
        //Mejor la dejo dormir hasta ma;ana
        //
    }
    /**
     * 
     * @param datos
     * @param nodo 
     */
    NodoLista (Object datos, NodoLista nodo){
         this.datos= datos;

         //siguienteNodo= nodo;
         
         
    }
    
}